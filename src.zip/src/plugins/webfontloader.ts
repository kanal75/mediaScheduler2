/**
 * plugins/webfontloader.js
 *
 * webfontloader documentation: https://github.com/typekit/webfontloader
 */

// Google Fonts loading removed. This file is now a no-op.
export async function loadFonts() {
  // No-op: Google Fonts loading disabled for local fonts only
}
